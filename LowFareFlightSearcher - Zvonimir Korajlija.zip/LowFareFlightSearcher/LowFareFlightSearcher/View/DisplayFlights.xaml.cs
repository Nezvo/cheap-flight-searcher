﻿using System.Windows;

namespace LowFareFlightSearcher.View
{
	/// <summary>
	/// Interaction logic for DisplayFlights.xaml
	/// </summary>
	public partial class DisplayFlights : Window
	{
		public DisplayFlights()
		{
			InitializeComponent();
		}
	}
}
